﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPINatureHub3.Models;
using WebAPINatureHub3.RemedyDtos;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RemediesController : ControllerBase
    {
        private readonly NatureHub3Context _context;

        public RemediesController(NatureHub3Context context)
        {
            _context = context;
        }

        // POST: api/Remedies
        [HttpPost]
        public async Task<IActionResult> CreateRemedy([FromForm] CreateRemedyDTO createRemedyDTO, IFormFile file)
        {
            // Validate the provided file
            if (file == null || file.Length == 0)
            {
                return BadRequest("No image to upload");
            }

            // Convert the image to byte array
            byte[] fileData;
            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                fileData = memoryStream.ToArray();
            }

            // Create remedy entity
            var remedy = new Remedy
            {
                RemedyName = createRemedyDTO.RemedyName,
                Description = createRemedyDTO.Description,
                Benefits = createRemedyDTO.Benefits,
                PreparationMethod = createRemedyDTO.PreparationMethod,
                UsageInstructions = createRemedyDTO.UsageInstructions,
                CategoryId = createRemedyDTO.CategoryId,
                Remediesimg = fileData // Store the image in the database as byte[]
            };

            _context.Remedies.Add(remedy);
            await _context.SaveChangesAsync();

            // Return the created remedy as ReadRemedyDTO
            var readRemedyDTO = new ReadRemedyDTO
            {
                RemedyId = remedy.RemedyId,
                RemedyName = remedy.RemedyName,
                Description = remedy.Description,
                Benefits = remedy.Benefits,
                PreparationMethod = remedy.PreparationMethod,
                UsageInstructions = remedy.UsageInstructions,
                Remediesimg = remedy.Remediesimg,
                CategoryId = remedy.CategoryId
            };

            return Ok(readRemedyDTO); // Return the created remedy object directly without headers
        }

        // GET: api/Remedies/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRemedy(int id)
        {
            var remedy = await _context.Remedies.FindAsync(id);
            if (remedy == null)
            {
                return NotFound("Remedy not found.");
            }

            var readRemedyDTO = new ReadRemedyDTO
            {
                RemedyId = remedy.RemedyId,
                RemedyName = remedy.RemedyName,
                Description = remedy.Description,
                Benefits = remedy.Benefits,
                PreparationMethod = remedy.PreparationMethod,
                UsageInstructions = remedy.UsageInstructions,
                Remediesimg = remedy.Remediesimg,
                CategoryId = remedy.CategoryId
            };

            return Ok(readRemedyDTO); // Return the remedy object directly
        }

        // PUT: api/Remedies/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRemedy(int id, [FromForm] UpdateRemedyDTO updateRemedyDTO, [FromForm] IFormFile? file)
        {
            var remedy = await _context.Remedies.FindAsync(id);
            if (remedy == null)
            {
                return NotFound("Remedy not found.");
            }

            // Update remedy properties
            remedy.RemedyName = updateRemedyDTO.RemedyName;
            remedy.Description = updateRemedyDTO.Description;
            remedy.Benefits = updateRemedyDTO.Benefits;
            remedy.PreparationMethod = updateRemedyDTO.PreparationMethod;
            remedy.UsageInstructions = updateRemedyDTO.UsageInstructions;
            remedy.CategoryId = updateRemedyDTO.CategoryId;

            // If new image is provided, update it
            if (file != null && file.Length > 0)
            {
                byte[] fileData;
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    fileData = memoryStream.ToArray();
                }
                remedy.Remediesimg = fileData; // Update image in the database
            }

            await _context.SaveChangesAsync();
            return Ok(new { Message = "Remedy updated successfully!" }); // Return success message
        }

        // DELETE: api/Remedies/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRemedy(int id)
        {
            var remedy = await _context.Remedies.FindAsync(id);
            if (remedy == null)
            {
                return NotFound("Remedy not found.");
            }

            _context.Remedies.Remove(remedy);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Remedy deleted successfully!" }); // Return success message
        }

        // GET: api/Remedies
        [HttpGet]
        public async Task<IActionResult> GetAllRemedies()
        {
            var remedies = await _context.Remedies.ToListAsync();
            if (!remedies.Any())
            {
                return NotFound("No remedies found.");
            }

            var readRemediesDTO = remedies.Select(remedy => new ReadRemedyDTO
            {
                RemedyId = remedy.RemedyId,
                RemedyName = remedy.RemedyName,
                Description = remedy.Description,
                Benefits = remedy.Benefits,
                PreparationMethod = remedy.PreparationMethod,
                UsageInstructions = remedy.UsageInstructions,
                Remediesimg = remedy.Remediesimg,
                CategoryId = remedy.CategoryId
            }).ToList();

            return Ok(readRemediesDTO); // Return list of all remedies
        }
    }
}

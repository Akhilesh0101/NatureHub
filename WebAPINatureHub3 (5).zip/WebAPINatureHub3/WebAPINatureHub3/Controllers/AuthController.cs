﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Linq;
using WebAPINatureHub3.Models;
using Microsoft.CodeAnalysis.Scripting;
using System.Configuration;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly NatureHub3Context _context;
        private readonly IConfiguration _configuration;
        private readonly EmailService _emailService;

        public AuthController(NatureHub3Context context, IConfiguration configuration, EmailService emailService)
        {
            _context = context;
            _configuration = configuration;
            _emailService = emailService;
        }

        // Admin Login
        [HttpPost("adminlogin")]
        public IActionResult AdminLogin([FromBody] AdminLoginDto loginDto)
        {
            var admin = _context.Admins.SingleOrDefault(u => u.Username == loginDto.Username && u.Email == loginDto.Email);
            if (admin == null || admin.Password != loginDto.Password) // Directly compare the plain password
            {
                return Unauthorized("Invalid credentials.");
            }

            var token = GenerateJwtToken(admin.Username, "Admin");
            return Ok(new { token });
        }

        // User Login
        [HttpPost("userlogin")]
        public IActionResult UserLogin([FromBody] UserLoginDto loginDto)
        {
            var user = _context.Users.SingleOrDefault(u => u.UserName == loginDto.UserName && u.Email == loginDto.Email);
            if (user == null || user.Password != loginDto.Password) // Directly compare the plain password
            {
                return Unauthorized("Invalid credentials.");
            }

            var token = GenerateJwtToken(user.UserName, "User");
            return Ok(new { token });
        }

        // User Signup
        [HttpPost("signup")]
        public async Task<IActionResult> Signup([FromForm] UserSignupDto signupDto)
        {
            // Check if the username or email already exists
            if (_context.Users.Any(u =>  u.Email == signupDto.Email))
            {
                return BadRequest("Username or Email already exists.");
            }

            // Create a new user (Storing plain text password)
            var user = new User
            {
                UserName = signupDto.UserName,
                Email = signupDto.Email,
                Password = signupDto.Password, // Store plain text password
                RoleId = 2 // Default RoleId for users
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            // Send a confirmation email after user is created
            var subject = "Welcome to Nature Hub! 🌿";
            var body = $"Hi {signupDto.UserName},\r\n\r\nWelcome to Nature Hub – we're so excited to have you! 🌟\r\n\r\nHere," +
                $" you'll explore inspiring content, connect with nature enthusiasts 🌍, and discover ways to make a positive impact.\r\n\r\nDive into our community, personalize your profile, and start your journey today! 🌱\r\n\r\nHave questions or need help? We're just a message away." +
                $" 💬\r\n\r\nTogether, let’s nurture the planet! 🌳\r\n\r\nWarm wishes,\r\nThe Nature Hub Team 🌏</p>";

            try
            {
                // Send email
                await _emailService.SendEmailAsync(signupDto.Email, signupDto.UserName, body);
            }
            catch (Exception ex)
            {
                // Log or handle the exception
                return StatusCode(500, $"Internal server error while sending email: {ex.Message}");
            }

            return CreatedAtAction("GetUser", "Users", new { id = user.UserId }, user);
        }

        // Helper function to generate JWT token
        private string GenerateJwtToken(string username, string role)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, username),
                new Claim(ClaimTypes.Role, role),
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credential = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddMinutes(50),
                signingCredentials: credential
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }

    // DTOs
    public class AdminLoginDto
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class UserLoginDto
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class UserSignupDto
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPINatureHub3.Models;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookmarksController : ControllerBase
    {
        private readonly NatureHub3Context _context;

        public BookmarksController(NatureHub3Context context)
        {
            _context = context;
        }

        // GET: api/Bookmarks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Bookmark>>> GetBookmarks()
        {
            return await _context.Bookmarks.ToListAsync();
        }

        // GET: api/Bookmarks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Bookmark>> GetBookmark(int id)
        {
            var bookmark = await _context.Bookmarks.FindAsync(id);

            if (bookmark == null)
            {
                return NotFound();
            }

            return bookmark;
        }

        // POST: api/Bookmarks
        // Create a new bookmark using UserID and RemedyID
        [HttpPost]
        public async Task<IActionResult> PostBookmark([FromBody] BookmarkRequest request)
        {
            // Validate if the RemedyID exists
            var remedy = await _context.Remedies.FindAsync(request.RemedyID);
            if (remedy == null)
            {
                return BadRequest("Invalid Remedy ID.");
            }

            // Validate if the UserID exists (optional based on your design)
            var user = await _context.Users.FindAsync(request.UserID);
            if (user == null)
            {
                return BadRequest("Invalid User ID.");
            }

            // Check if the user has already bookmarked this remedy
            var existingBookmark = await _context.Bookmarks
                .Where(b => b.UserId == request.UserID && b.RemedyId == request.RemedyID)
                .FirstOrDefaultAsync();

            if (existingBookmark != null)
            {
                return BadRequest("You have already bookmarked this remedy.");
            }

            // Create the new bookmark
            var bookmark = new Bookmark
            {
                UserId = request.UserID,
                RemedyId = request.RemedyID
            };

            _context.Bookmarks.Add(bookmark);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBookmark", new { id = bookmark.BookmarkId }, bookmark);
        }

        // DELETE: api/Bookmarks/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBookmark(int id)
        {
            var bookmark = await _context.Bookmarks.FindAsync(id);
            if (bookmark == null)
            {
                return NotFound();
            }

            _context.Bookmarks.Remove(bookmark);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Private method to check if a bookmark exists by its ID
        private bool BookmarkExists(int id)
        {
            return _context.Bookmarks.Any(e => e.BookmarkId == id);
        }
    }

    // DTO for bookmarking (only UserID and RemedyID)
    public class BookmarkRequest
    {
        public int UserID { get; set; }
        public int RemedyID { get; set; }
    }
}

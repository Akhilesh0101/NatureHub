﻿using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace WebAPINatureHub3
{
    public class EmailService
    {
        private readonly string _senderEmail;
        private readonly string _senderPassword;

        // Constructor to inject sender email and app password (use app password if 2FA is enabled)
        public EmailService(string senderEmail, string senderPassword)
        {
            _senderEmail = senderEmail;
            _senderPassword = senderPassword;
        }

        // Async method to send a welcome email
        public async Task SendWelcomeEmailAsync(string recipientEmail, string userName)
        {
            try
            {
                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(_senderEmail, _senderPassword),
                    EnableSsl = true
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_senderEmail),
                    Subject = "Welcome to Nature Hub! 🌿",
                    Body = $"<h1>Hi</h1><p>  {userName},\r\n\r\nWelcome to Nature Hub – we're so excited to have you! 🌟\r\n\r\nHere, you'll explore inspiring content, connect with nature enthusiasts 🌍, and discover ways to make a positive impact.\r\n\r\nDive into our community, personalize your profile, and start your journey today! 🌱\r\n\r\nHave questions or need help? We're just a message away. 💬\r\n\r\nTogether, let’s nurture the planet! 🌳\r\n\r\nWarm wishes,\r\nThe Nature Hub Team 🌏</p>",
                    IsBodyHtml = true
                };

                mailMessage.To.Add(recipientEmail);

                // Send the email asynchronously
                await smtpClient.SendMailAsync(mailMessage);
            }
            catch (SmtpException smtpEx)
            {
                // Log the error or handle it in a way that makes sense for your application
                throw new Exception("SMTP error occurred: " + smtpEx.Message);
            }
            catch (Exception ex)
            {
                // Log the error or handle it in a way that makes sense for your application
                throw new Exception("Failed to send email: " + ex.Message);
            }
        }

        // This is an unused placeholder method. If you plan to use it, you can implement it like the SendWelcomeEmailAsync method.
        public async Task SendEmailAsync(string recipientEmail, string subject, string body)
        {
            try
            {
                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(_senderEmail, _senderPassword),
                    EnableSsl = true
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_senderEmail),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };

                mailMessage.To.Add(recipientEmail);

                // Send the email asynchronously
                await smtpClient.SendMailAsync(mailMessage);
            }
            catch (SmtpException smtpEx)
            {
                throw new Exception("SMTP error occurred: " + smtpEx.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to send email: " + ex.Message);
            }
        }
    }
}
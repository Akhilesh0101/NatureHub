﻿namespace WebAPINatureHub3.RemedyDtos
{
    public class UpdateRemedyDTO
    {

        public int RemedyId { get; set; }

        public string RemedyName { get; set; }       

        public string Description { get; set; }

        public string Benefits { get; set; }

        public string PreparationMethod { get; set; }

        public string UsageInstructions { get; set; }

        public int CategoryId { get; set; }

    }
}

﻿namespace WebAPINatureHub3.RemedyDtos
{
    public class CreateRemedyDTO
    {
       
        public string RemedyName { get; set; } = null!;

     

        public string Description { get; set; }

        public string Benefits { get; set; }

        public string PreparationMethod { get; set; }

        public string UsageInstructions { get; set; }

    
        public int CategoryId { get; set; }

       
    }
}

